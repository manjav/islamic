Thanks for visiting MaterialDesignIcons.com
Check back often for new icons and follow @MaterialIcons for updates.

Icon: calendar-multiple
By: Austin Andrews